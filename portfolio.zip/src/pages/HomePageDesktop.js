import Header from "../components/Header";
import Container7 from "../components/Container7";
import Container6 from "../components/Container6";
import Container4 from "../components/Container4";
import Container3 from "../components/Container3";
import Container2 from "../components/Container2";
import Container1 from "../components/Container1";
import Container from "../components/Container";
import "./HomePageDesktop.css";

const HomePageDesktop = () => {
  return (
    <div className="home-page-desktop">
      <section className="frame" id="section1">
        <Header />
        <Container7 />
      </section>
      <Container6 />
      <Container4 />
      <Container3 />
      <Container2 />
      <Container1 />
      <Container />
    </div>
  );
};

export default HomePageDesktop;
