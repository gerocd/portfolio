import "./TextContainer.css";

const TextContainer = () => {
  return (
    <div className="text-container8">
      <div className="text25">FAQ’s</div>
      <h1 className="heading13">Frequently Asked Questions</h1>
    </div>
  );
};

export default TextContainer;
