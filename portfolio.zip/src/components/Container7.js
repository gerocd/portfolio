import SubContainer8 from "./SubContainer8";
import SubContainer7 from "./SubContainer7";
import "./Container7.css";

const Container7 = () => {
  return (
    <div className="container3">
      <SubContainer8 />
      <SubContainer7 />
    </div>
  );
};

export default Container7;
