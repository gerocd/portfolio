import { useMemo } from "react";
import "./ContainerWithButtons.css";

const ContainerWithButtons = ({ icon, icon1, text, propWidth }) => {
  const containerStyle = useMemo(() => {
    return {
      width: propWidth,
    };
  }, [propWidth]);

  return (
    <div className="container19" style={containerStyle}>
      <a className="button16" href="https://github.com/gerocd" target="_blank">
        <div className="text19">{text}</div>
      </a>
    </div>
  );
};

export default ContainerWithButtons;
