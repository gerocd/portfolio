import "./SubContainer7.css";

const SubContainer7 = () => {
  return (
    <div className="sub-container-2">
      <div className="container1">
        <div className="sub-container2">
          <img className="icon1" alt="" src="/icon@2x.png" />
          <div className="net-c">{`jira & thunderclient`}</div>
        </div>
        <div className="sub-container2">
          <img className="icon1" alt="" src="/icon1@2x.png" />
          <div className="net-c">SQL DATABASES</div>
        </div>
        <div className="sub-container2">
          <img className="icon1" alt="" src="/icon2@2x.png" />
          <div className="net-c">{`API & REST API`}</div>
        </div>
        <div className="sub-container2">
          <img className="icon1" alt="" src="/icon3@2x.png" />
          <div className="net-c">.NET C#</div>
        </div>
        <div className="sub-container2">
          <img className="icon1" alt="" src="/icon4@2x.png" />
          <div className="net-c">react</div>
        </div>
        <div className="sub-container2">
          <img className="icon1" alt="" src="/icon5@2x.png" />
          <div className="text7">node.jS</div>
        </div>
        <div className="sub-container2">
          <img className="icon1" alt="" src="/icon6@2x.png" />
          <div className="net-c">{`javascript `}</div>
        </div>
      </div>
      <div className="container2">
        <img
          className="images-container-icon"
          alt=""
          src="/images-container@2x.png"
        />
      </div>
    </div>
  );
};

export default SubContainer7;
