import ClientCard from "./ClientCard";
import "./ItemsOpinionContainer.css";

const ItemsOpinionContainer = () => {
  return (
    <div className="items-container">
      <ClientCard
        name1="Emily Johnson"
        icon="/icon16@2x.png"
        icon1="/icon17@2x.png"
        icon2="/icon18@2x.png"
        paragraph="Damien's photography doesn't just capture moments; it captures emotions. Hes work is simply mesmerizing."
        propLeft="calc(50% - 607px)"
        propTop="0px"
        propLeft1="620.5px"
        frameWidth="532px"
        framePadding="var(--padding-0) var(--padding-0) var(--padding-0) 11.00000286102295px"
        frameHeight="521px"
      />
      <ClientCard
        name1="John Smith"
        icon="/icon19.svg"
        icon1="/icon20.svg"
        icon2="/vector.svg"
        paragraph="Damien has an incredible talent for making every event feel effortless, and the results speak for themselves."
      />
      <ClientCard
        name1="Samantha Davis"
        icon="/icon19.svg"
        icon1="/icon20.svg"
        icon2="/vector.svg"
        paragraph="I was blown away by Damien's ability to capture the essence of our wedding day. Hes photographs are our cherished memories."
        propLeft="calc(50% - 606.7px)"
        propTop="18px"
        propLeft1="597.5px"
        frameWidth="520.7px"
        framePadding="var(--padding-0) var(--padding-0) var(--padding-0) 0.0000025648678274592385px"
        frameHeight="unset"
      />
    </div>
  );
};

export default ItemsOpinionContainer;
