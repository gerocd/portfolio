import "./SubContainer8.css";

const SubContainer8 = () => {
  return (
    <div className="sub-container">
      <img
        className="abstract-design-icon"
        alt=""
        src="/abstract-design@2x.png"
      />
      <div className="text-container">
        <h1 className="heading">cÓRDOBA GERÓNIMO</h1>
      </div>
      <div className="container">
        <div className="sub-container1">
          <h1 className="heading1">Let’s</h1>
          <button className="button5">
            <div className="icon">
              <img
                className="vector-431-stroke"
                alt=""
                src="/vector-431-stroke@2x.png"
              />
            </div>
          </button>
        </div>
        <h1 className="text2">Work Together</h1>
      </div>
    </div>
  );
};

export default SubContainer8;
