import SubContainer2 from "./SubContainer2";
import ItemsOpinionContainer from "./ItemsOpinionContainer";
import "./Container1.css";

const Container1 = () => {
  return (
    <div className="container27" id="Container5">
      <SubContainer2 />
      <ItemsOpinionContainer />
    </div>
  );
};

export default Container1;
