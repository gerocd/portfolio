import TextContainer from "./TextContainer";
import SubContainer3 from "./SubContainer3";
import "./Container2.css";

const Container2 = () => {
  return (
    <div className="container23" id="Container4">
      <TextContainer />
      <SubContainer3 />
    </div>
  );
};

export default Container2;
