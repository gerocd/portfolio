import FAQForm from "./FAQForm";
import "./FAQContainer1.css";

const FAQContainer1 = () => {
  return (
    <div className="faq-container">
      <div className="faq-item-open">
        <div className="text-container9">
          <div className="heading15">
            What type of photography do you specialize in?
          </div>
          <div className="paragraph2">
            I specialize in [Portrait, Landscape, Event, etc.] photography,
            capturing moments that tell unique stories.
          </div>
        </div>
        <div className="button20">
          <img className="icon22" alt="" src="/icon12.svg" />
        </div>
      </div>
      <div className="line" />
      <FAQForm questionText="How can I book a photography session with you?" />
      <div className="line" />
      <FAQForm questionText="What equipment do you use for your photography?" />
      <div className="line" />
      <FAQForm questionText="Can I request a specific location for a " />
    </div>
  );
};

export default FAQContainer1;
