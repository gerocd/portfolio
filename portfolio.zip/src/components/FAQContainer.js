import FAQForm from "./FAQForm";
import "./FAQContainer.css";

const FAQContainer = () => {
  return (
    <div className="faq-container1">
      <FAQForm questionText="What is your editing process like?" />
      <div className="line3" />
      <FAQForm questionText="Are digital files included in your photography packages?" />
      <div className="line3" />
      <div className="faq-item-open1">
        <div className="text-container10">
          <div className="heading16">
            Do you offer prints of your photographs?
          </div>
          <div className="paragraph3">
            Yes, prints are available for purchase. Explore the 'Prints' section
            for more details on sizes and pricing.
          </div>
        </div>
        <div className="button21">
          <img className="icon23" alt="" src="/icon12.svg" />
        </div>
      </div>
      <div className="line3" />
      <FAQForm questionText="How long does it take to receive the edited photos after a session?" />
    </div>
  );
};

export default FAQContainer;
