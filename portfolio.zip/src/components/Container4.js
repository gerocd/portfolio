import SubContainer6 from "./SubContainer6";
import Container5 from "./Container5";
import "./Container4.css";

const Container4 = () => {
  return (
    <div className="container18" id="Container2">
      <SubContainer6 />
      <Container5 />
    </div>
  );
};

export default Container4;
