import "./Container8Footer.css";

const Container8Footer = () => {
  return (
    <footer className="container33" id="footer">
      <div className="sub-container31">
        <div className="text-button3">{`Terms & Conditions`}</div>
        <div className="line6" />
        <div className="text-button3">Privacy Policy</div>
      </div>
      <div className="text45">
        © 2024 Gerónimo Martín Córdoba. All rights reserved.
      </div>
      <div className="buttons-container5">
        <div className="button32">
          <img className="icon35" alt="" src="/icon@2x.png" />
        </div>
        <div className="button33">
          <img className="icon36" alt="" src="/icon20.svg" />
        </div>
        <div className="button33">
          <img className="icon36" alt="" src="/vector.svg" />
        </div>
      </div>
    </footer>
  );
};

export default Container8Footer;
