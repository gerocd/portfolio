import "./ButtonsContainer.css";

const ButtonsContainer = () => {
  return (
    <nav className="buttons-container" id="Navbar">
      <button className="button">
        <div className="text">Home</div>
      </button>
      <button className="button1">
        <div className="text-button">About Me</div>
      </button>
      <button className="button1">
        <div className="text-button">Portfolio</div>
      </button>
      <button className="button3">
        <div className="text-button">Services</div>
      </button>
    </nav>
  );
};

export default ButtonsContainer;
