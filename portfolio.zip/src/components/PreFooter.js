import SubContainer from "./SubContainer";
import SubContainerLinks from "./SubContainerLinks";
import "./PreFooter.css";

const PreFooter = () => {
  return (
    <div className="container32">
      <SubContainer />
      <SubContainerLinks />
      <img
        className="abstract-design-icon1"
        alt=""
        src="/abstract-design1@2x.png"
      />
      <img
        className="abstract-design-icon2"
        alt=""
        src="/abstract-design2@2x.png"
      />
    </div>
  );
};

export default PreFooter;
