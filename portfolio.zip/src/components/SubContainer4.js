import CardContainer2 from "./Card";
import "./SubContainer4.css";

const SubContainer4 = () => {
  return (
    <div className="sub-container-21">
      <div className="card1">
        <img className="image-icon3" alt="" src="/image@2x.png" />
        <div className="container21">
          <div className="text-container7">
            <div className="heading12">Gym System</div>
            <div className="text23">March 2022</div>
          </div>
          <a className="button18" href="https://github.com/gerocd/SistGimnasio">
            <div className="text24">View Project</div>
            <button className="icon20">
              <img
                className="vector-431-stroke1"
                alt=""
                src="/vector-431-stroke@2x.png"
              />
            </button>
          </a>
        </div>
      </div>
      <CardContainer2
        dimensionCode="/image@2x.png"
        componentTitle="API SYSTEM"
        imageCode="/icon11@2x.png"
      />
      <CardContainer2
        dimensionCode="/image@2x.png"
        componentTitle="Crunchyroll Imitation"
        imageCode="/icon@2x.png"
      />
    </div>
  );
};

export default SubContainer4;
