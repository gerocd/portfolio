import "./SubContainerLinks.css";

const SubContainerLinks = () => {
  return (
    <div className="sub-container30">
      <div className="links-container">
        <div className="text38">Home</div>
        <div className="container30">
          <div className="button26">
            <button className="text39">About Me</button>
          </div>
          <div className="button26">
            <div className="text40">My Works</div>
          </div>
          <div className="button26">
            <button className="text39">fiverr</button>
          </div>
        </div>
      </div>
      <div className="links-container">
        <div className="text38">social media</div>
        <div className="container31">
          <div className="button26">
            <button className="text39">instagram</button>
          </div>
          <div className="button30">
            <button className="text39">Events</button>
          </div>
          <div className="button26">
            <button className="text39">linkedin</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SubContainerLinks;
