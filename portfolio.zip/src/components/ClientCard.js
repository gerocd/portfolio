import { useMemo } from "react";
import "./ClientCard.css";

const ClientCard = ({
  name1,
  icon,
  icon1,
  icon2,
  paragraph,
  propLeft,
  propTop,
  propLeft1,
  frameWidth,
  framePadding,
  frameHeight,
}) => {
  const abstractDesignStyle = useMemo(() => {
    return {
      left: propLeft,
    };
  }, [propLeft]);

  const frameStyle = useMemo(() => {
    return {
      top: propTop,
      left: propLeft1,
      width: frameWidth,
      padding: framePadding,
      height: frameHeight,
    };
  }, [propTop, propLeft1, frameWidth, framePadding, frameHeight]);

  return (
    <div className="card2">
      <div className="container25">
        <div className="text-container13">
          <div className="name">{name1}</div>
          <div className="text28">USA, California</div>
        </div>
        <div className="buttons-container4">
          <div className="button22">
            <img className="icon24" alt="" src={icon} />
          </div>
          <div className="button22">
            <img className="icon24" alt="" src={icon1} />
          </div>
          <div className="button22">
            <img className="icon24" alt="" src={icon2} />
          </div>
        </div>
      </div>
      <div className="container26">
        <img className="shape-icon" alt="" src="/shape.svg" />
        <img className="shape-icon" alt="" src="/shape.svg" />
        <img className="shape-icon" alt="" src="/shape.svg" />
        <img className="shape-icon" alt="" src="/shape.svg" />
        <img className="shape-icon" alt="" src="/shape.svg" />
      </div>
      <div className="paragraph4">{paragraph}</div>
      <div className="abstract-design" style={abstractDesignStyle}>
        <div className="shape" />
        <div className="frame1" style={frameStyle}>
          <div className="shape1" />
        </div>
      </div>
    </div>
  );
};

export default ClientCard;
