import { useCallback } from "react";
import "./SubContainer6.css";

const SubContainer6 = () => {
  const onButtonContainer1Click = useCallback(() => {
    //TODO: search cards
  }, []);

  return (
    <div className="sub-container13">
      <div className="text-container4">
        <h1 className="heading7">SOME OF MY PROJECTS</h1>
      </div>
      <div className="container10">
        <div className="buttons-container3">
          <div className="button12">
            <button className="icon13">
              <img className="vector-icon3" alt="" src="/vector@2x.png" />
            </button>
          </div>
          <div className="button13" onClick={onButtonContainer1Click}>
            <img className="icon14" alt="" src="/icon@2x.png" />
          </div>
        </div>
        <button className="button14">
          <div className="text15">{`View All Projects ->`}</div>
        </button>
      </div>
    </div>
  );
};

export default SubContainer6;
