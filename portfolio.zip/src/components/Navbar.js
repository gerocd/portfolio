import ButtonsContainer from "./ButtonsContainer";
import "./Navbar.css";

const Navbar = () => {
  return (
    <nav className="navbar">
      <img className="logo-icon" alt="" src="/name@2x.png" />
      <button className="button4">
        <div className="text1">Contact Me</div>
      </button>
      <ButtonsContainer />
    </nav>
  );
};

export default Navbar;
