import SubContainer5 from "./SubContainer5";
import SubContainer4 from "./SubContainer4";
import "./Container3.css";

const Container3 = () => {
  return (
    <div className="container22" id="Container3">
      <SubContainer5 />
      <SubContainer4 />
    </div>
  );
};

export default Container3;
