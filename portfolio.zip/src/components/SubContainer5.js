import ContainerWithButtons from "./ContainerWithButtons";
import "./SubContainer5.css";

const SubContainer5 = () => {
  return (
    <div className="sub-container17">
      <div className="text-container5">
        <div className="text20">Portfolio</div>
        <h1 className="heading10">EXPLORE SOME OF MY REPOSITORIES.</h1>
      </div>
      <ContainerWithButtons text={`View All Works ->`} />
    </div>
  );
};

export default SubContainer5;
