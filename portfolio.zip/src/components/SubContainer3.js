import FAQContainer1 from "./FAQContainer1";
import FAQContainer from "./FAQContainer";
import "./SubContainer3.css";

const SubContainer3 = () => {
  return (
    <div className="sub-container18">
      <FAQContainer1 />
      <FAQContainer />
    </div>
  );
};

export default SubContainer3;
