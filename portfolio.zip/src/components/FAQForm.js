import "./FAQForm.css";

const FAQForm = ({ questionText }) => {
  return (
    <div className="faq-item">
      <div className="heading14">{questionText}</div>
      <div className="button19">
        <img className="icon21" alt="" src="/icon13.svg" />
      </div>
    </div>
  );
};

export default FAQForm;
