import "./SubContainer1.css";

const SubContainer1 = () => {
  return (
    <div className="sub-container20">
      <div className="container28">
        <div className="sub-container21">
          <img className="icon27" alt="" src="/icon@2x.png" />
          <div className="text29">{`jira & thunderclient`}</div>
        </div>
        <div className="sub-container21">
          <img className="icon27" alt="" src="/icon@2x.png" />
          <div className="text29">SQL DATABASES</div>
        </div>
        <div className="sub-container21">
          <img className="icon27" alt="" src="/icon@2x.png" />
          <div className="text29">{`API & REST API`}</div>
        </div>
        <div className="sub-container21">
          <img className="icon27" alt="" src="/icon@2x.png" />
          <div className="text29">.NET C#</div>
        </div>
        <div className="sub-container21">
          <img className="icon27" alt="" src="/icon@2x.png" />
          <div className="text29">react</div>
        </div>
        <div className="sub-container21">
          <img className="icon27" alt="" src="/icon@2x.png" />
          <div className="text33">node.jS</div>
        </div>
        <div className="sub-container21">
          <img className="icon27" alt="" src="/icon@2x.png" />
          <div className="text29">{`javascript `}</div>
        </div>
      </div>
    </div>
  );
};

export default SubContainer1;
