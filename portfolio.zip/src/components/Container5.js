import "./Container5.css";

const Container5 = () => {
  return (
    <div className="container11">
      <div className="sub-container14">
        <div className="container12">
          <div className="sub-container15">
            <h1 className="heading8">GIT HUB</h1>
            <button className="button15">
              <img className="icon15" alt="" src="/icon9.svg" />
            </button>
          </div>
          <div className="paragraph1">
            Our event photography service is dedicated to capturing the magic of
            your special occasions. Whether it's a wedding, corporate event, or
            milestone celebration, we're there to document every heartfelt
            moment. We blend into the background, ensuring natural and candid
            shots that reflect the emotions of the day.
          </div>
        </div>
        <div className="container13">
          <div className="heading9">Service Highlights</div>
          <div className="sub-container16">
            <div className="container14">
              <img className="icon16" alt="" src="/icon10@2x.png" />
              <div className="text16">
                Coverage for weddings, parties, corporate functions, and more.
              </div>
            </div>
            <div className="container14">
              <img className="icon16" alt="" src="/icon10@2x.png" />
              <div className="text16">
                Skilled photographers who know how to seize the moment.
              </div>
            </div>
            <div className="container14">
              <img className="icon16" alt="" src="/icon10@2x.png" />
              <div className="text16">
                A mix of candid and posed shots for a comprehensive story.
              </div>
            </div>
            <input
              className="container17"
              placeholder="Quick turnaround for you to relive the day's highlights."
              type="text"
            />
          </div>
        </div>
      </div>
      <img className="image-icon1" alt="" src="/image@2x.png" />
    </div>
  );
};

export default Container5;
