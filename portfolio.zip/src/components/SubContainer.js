import "./SubContainer.css";

const SubContainer = () => {
  return (
    <div className="sub-container28">
      <div className="text35">A more meaningful home for photography</div>
      <div className="container29">
        <div className="sub-container29">
          <h1 className="text36">Let’s</h1>
          <div className="button25">
            <img className="icon34" alt="" src="/icon9.svg" />
          </div>
        </div>
        <h1 className="text37">Work Together</h1>
      </div>
    </div>
  );
};

export default SubContainer;
