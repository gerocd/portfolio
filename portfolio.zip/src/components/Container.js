import SubContainer1 from "./SubContainer1";
import Footer from "./Footer";
import "./Container.css";

const Container = () => {
  return (
    <div className="container34" id="Container6">
      <SubContainer1 />
      <Footer />
    </div>
  );
};

export default Container;
